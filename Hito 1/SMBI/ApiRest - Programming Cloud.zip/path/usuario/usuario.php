<?php
	class RestUsuario{
		// GET usuario/get/[loginUsu]
		static public function getUsuario($usuario){
			$query = 'SELECT * FROM Usuario u WHERE u.Login = :login';

			$usu = getDatabase()->one($query, array(':login' => $usuario));
			$json = json_encode($usu);

			echo $json;
		}

		// GET usuario/listado/[orden]
		static public function getListaUsu($orden){
			$query = 'SELECT * FROM Usuario ';

			//orden = login/nombre/apellidos
			switch($orden){
				case 'login':
					$query .= 'ORDER BY Login';
				break;
				case 'nombre':
					$query .= 'ORDER BY nombre, apellidos';
				break;
				case 'apellidos':
					$query .= 'ORDER BY apellidos, nombre';
				break;
				default:
					$query .= 'ORDER BY Login';
				break;
			}
			
			$usu = getDatabase()->all($query);
			$json = json_encode($usu);

			echo $json;		
		}
		
		// GET usuario/usureg/free/listado
		static public function getListaFree(){
			$query = 'SELECT * FROM Free';

			$usu = getDatabase()->all($query);
			$json = json_encode($usu);

			echo $json;		
		}
		
		// GET usuario/ejercicios/listado/[loginUsu]
		static public function getEjercicios($login){
			$query = 'SELECT s.id_ej, s.fecha, e.valoracion FROM Sube s, Ejercicio e WHERE s.login_usu = :loginUsuario AND e.id = s.id_ej';

			$usu = getDatabase()->all($query, array(':loginUsuario' => $login));
			$json = json_encode($usu);

			echo $json;		
		}

		// GET usuario/ejercicios/videojuegos/listado/[loginUsu]
		static public function getVideojuegos($login){
			$query = 'SELECT s.id_ej, e.valoracion, j.url_serv FROM Sube s, Juego j, Ejercicio e WHERE s.login_usu = :loginUsuario AND s.id_ej = e.id AND j.id = e.id';

			$usu = getDatabase()->all($query, array(':loginUsuario' => $login));
			$json = json_encode($usu);

			echo $json;		
		}

		// GET usuario/ejercicios/ejnormales/listado/[loginUsu]
		static public function getEjNormales($login){
			$query = 'SELECT s.fecha, e.valoracion, n.pregunta, n.respuesta FROM Sube s, NormalEj n, Ejercicio e WHERE s.login_usu = :loginUsuario AND s.id_ej = e.id AND e.id = n.id';

			$usu = getDatabase()->all($query, array(':loginUsuario' => $login));
			$json = json_encode($usu);

			echo $json;		
		}
	}

	class RestUsuarioPost{

		static public function createUsuario($login,$pass,$email,$nombre,$apellidos,$photo){
			$nombre=str_replace("_", " ", $nombre);
			$apellidos=str_replace("_", " ", $apellidos);

			$query = 'INSERT INTO Usuario (login, password, email, nombre, apellidos, photo) VALUES (:login, :pass, :email, :nom, :apell, :photo)';

			$ej = getDatabase()->execute($query, array(':login' => $login,':pass' => $pass, ':email' => $email,
				':nom' => $nombre, ':apell' => $apellidos, ':photo' => $photo));

			
			$query2 = 'INSERT INTO UsuarioRegistrado (Login) VALUES (:login)';

			$ej2 = getDatabase()->execute($query2, array(':login' => $login));


			$json = json_encode($ej);

			echo $json;
		}

		static public function modifyUsuario($login,$pass,$email,$nombre,$apellidos,$photo){
			$nombre=str_replace("_", " ", $nombre);
			$query = 'UPDATE Usuario SET login = :login, password = :pass, email = :email, nombre = :nom, apellidos = :apell, photo = :photo WHERE Usuario.login = :login';

			$ej = getDatabase()->execute($query, array(':login' => $login,':pass' => $pass, ':email' => $email,
				':nom' => $nombre, ':apell' => $apellidos, ':photo' => $photo));
			$json = json_encode($ej);

			echo $json;
		}

		static public function modifyUsuarioNombre($login,$nombre){
			$nombre=str_replace("_", " ", $nombre);
			$query = 'UPDATE Usuario SET nombre = :nom WHERE Usuario.login = :login';

			$ej = getDatabase()->execute($query, array(':login' => $login, ':nom' => $nombre));
			$json = json_encode($ej);

			echo $json;
		}

		static public function modifyUsuarioEmail($login,$email){
			$apelli=str_replace("_", " ", $apelli);
			$query = 'UPDATE Usuario SET email = :email WHERE Usuario.login = :login';

			$ej = getDatabase()->execute($query, array(':login' => $login, ':email' => $email));
			$json = json_encode($ej);

			echo $json;
		}

		static public function modifyUsuarioPass($login,$pass){

			$query = 'UPDATE Usuario SET password = :pass WHERE Usuario.login = :login';

			$ej = getDatabase()->execute($query, array(':login' => $login, ':pass' => $pass));
			$json = json_encode($ej);

			echo $json;
		}

		static public function deleteUsuario($id){
			//primero compruebo si tiene conexion con Aulas_Curso

			/*$query = 'DELETE FROM Aula_Curso WHERE Aula_Curso.id_aula = :idAula';

			$ej = getDatabase()->execute($query, array(':idAula' => $id));*/
			$query = 'DELETE FROM UsuarioRegistrado WHERE UsuarioRegistrado.Login = :idAlu';
			$ej = getDatabase()->execute($query, array(':idAlu' => $id));

			$query = 'DELETE FROM Usuario WHERE Usuario.login = :idAlu';

			$ej = getDatabase()->execute($query, array(':idAlu' => $id));
			$json = json_encode($ej);

			echo $json;
		}

	}
?>