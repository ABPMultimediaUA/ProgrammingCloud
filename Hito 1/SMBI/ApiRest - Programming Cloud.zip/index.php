<?php

include_once './epiphany/src/Epi.php';
/*
include_once './path/pruebas/pruebas.php';
*/

include_once './path/noticia/noticia.php';

include_once './path/leccion/leccion.php';

include_once './path/streaming/streaming.php';
include_once './path/aula/aulas.php';
include_once './path/curso/curso.php';
include_once './path/Instituto/instituto.php';
include_once './path/usuario/usuario.php';
include_once './path/ejercicios/ejercicios.php';
include_once './path/usuario/usuarioRegistrado/usuarioRegistrado.php';
include_once './path/usuario/usuarioRegistrado/alumno/alumno.php';
include_once './path/usuario/usuarioRegistrado/free/free.php';
include_once './path/usuario/administrador/administrador.php';
include_once './path/usuario/administrador/gestor/gestor.php';
include_once './path/usuario/administrador/profesor/profesor.php';
include_once './path/usuario/usuarioRegistrado/premium/premium.php';
include_once './path/pack/pack.php';
/*


include_once './path/home/home.php';*/

chdir('.');
Epi::setPath('base', './epiphany/src');
Epi::setPath('config', dirname(__FILE__));
Epi::setSetting('exceptions', true);
Epi::init('route','database','api');
EpiDatabase::employ('mysql', 'ProgrammingCloud-ABP', '127.0.0.1', 'root', 'leb1705vt');

getDatabase()->execute("SET NAMES 'utf8'");

getRoute()->load('routes.ini');
/*
getRoute()->load('path/pruebas/routes.ini');
*/

getRoute()->load('path/noticia/routes.ini');
getRoute()->load('path/leccion/routes.ini');


getRoute()->load('path/streaming/routes.ini');
getRoute()->load('path/aula/routes.ini');
getRoute()->load('path/curso/routes.ini');
getRoute()->load('path/Instituto/routes.ini');
getRoute()->load('path/usuario/routes.ini');
getRoute()->load('path/ejercicios/routes.ini');
getRoute()->load('path/usuario/usuarioRegistrado/alumno/routes.ini');
getRoute()->load('path/usuario/usuarioRegistrado/free/routes.ini');
getRoute()->load('path/usuario/administrador/routes.ini');
getRoute()->load('path/usuario/administrador/gestor/routes.ini');
getRoute()->load('path/usuario/administrador/profesor/routes.ini');
getRoute()->load('path/usuario/usuarioRegistrado/premium/routes.ini');
getRoute()->load('path/pack/routes.ini');
getRoute()->load('path/usuario/usuarioRegistrado/routes.ini');
/*




;*/

getRoute()->run();
?>
