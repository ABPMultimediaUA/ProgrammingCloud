
/*************************************************CLASE TENTIDAD*******************************************/
class Tentidad{
    constructor(){}
    beginDraw(){}
    endDraw(){}
}