<?php
	class RestPruebas{
		static public function goHome(){
			echo 'El home funciona bien';
		}
		static public function goContactos(){
			echo 'El contacto tiene contactos';
		}
	}
?>
