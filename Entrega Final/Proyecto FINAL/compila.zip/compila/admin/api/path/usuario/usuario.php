<?php
	class RestUsuario{
		// GET usuario/get/[loginUsu]
		static public function getUsuario($usuario){
			/*$query = 'SELECT * FROM usuario u WHERE u.Email = :email';

			$usu = getDatabase()->one($query, array(':email' => $usuario));
			$json = json_encode($usu);

			echo $json;*/
		}

	}
?>