<?php

class Constants {
  const LOGGED_IN = 'logged_in';
}

?>
