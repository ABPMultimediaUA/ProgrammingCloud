<!DOCTYPE html>
<html>
<head>
	<title>PDF</title>
</head>
<body>
<p>Pulsa <a href="factura.php" target="blank">Aqui</a> para generar tu factura.</p>
</body>
</html>